LinkedList.h
BinarySearchTree.h
UnitTest.h

Main.cpp
	* creates objects of LinkedList and BST
	* tries their functions
	* tests with UnitTesting