#include "IState.h"



IState::IState()
{
}


IState::~IState()
{
}
