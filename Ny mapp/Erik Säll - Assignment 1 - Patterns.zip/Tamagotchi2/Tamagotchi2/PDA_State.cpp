#include "PDA_State.h"



PDA_State::PDA_State()
{
}


PDA_State::~PDA_State()
{
}

void PDA_State::Enter()
{
}


SwitchType PDA_State::GetSwitchType() const {
	return SwitchType::error;
}