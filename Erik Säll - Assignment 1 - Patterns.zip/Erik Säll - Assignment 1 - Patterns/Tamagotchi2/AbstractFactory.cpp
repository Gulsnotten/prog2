#include "AbstractFactory.h"


AbstractFactory::AbstractFactory()
{
}


AbstractFactory::~AbstractFactory()
{
}
