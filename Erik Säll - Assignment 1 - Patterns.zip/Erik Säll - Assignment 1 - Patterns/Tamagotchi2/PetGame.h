#pragma once
#include "StateMachine.h"
#include "PetFactory.h"
#include <ctime>

class PetGame
{
public:
	PetGame();
	~PetGame();

	void Run();
};

